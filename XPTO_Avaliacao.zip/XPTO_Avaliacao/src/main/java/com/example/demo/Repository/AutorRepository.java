package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entities.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long>{
	@Query(value = "SELECT * FROM Autor 1 WHERE lower(1.titulo) LIKE %:titulo%", nativeQuery = true)
	List<Autor> buscarPorTitutlo(@Param("titulo") String titulo);

}
