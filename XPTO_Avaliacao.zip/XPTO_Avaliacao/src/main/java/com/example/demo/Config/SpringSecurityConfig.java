package com.example.demo.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringSecurityConfig {
	
	@Bean
	public SecurityFilterAutoConfiguration filterChain(HttpSecurity http)throws Exception{
		http.authorizeHttpRequests((requests)-> requests
				.requestMatchers("/aluno/")
				//.anyRequest()
				.authenticated()
				
				)
				.httpBasic();
		return http.build();
		
	}
	
	@Bean
	public InMemoryUserDetailsManager userDetailsService(){
		UserDetails user = User.withDefaultPasswordEncoder()
				.username("admin")
				.password("admin")
				.build();
		return new InMemoryUserDetailsManager(user);
		
	}
	
}