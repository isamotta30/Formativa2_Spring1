package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{
	@Query(value = "SELECT * FROM Categoria 1 WHERE lower(1.titulo) LIKE %:titulo%", nativeQuery = true)
	List<Categoria> buscarPorTitutlo(@Param("titulo") String titulo);

}
