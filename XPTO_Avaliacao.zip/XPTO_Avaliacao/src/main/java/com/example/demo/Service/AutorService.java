package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Autor;
import com.example.demo.Repository.AutorRepository;

@Service
public class AutorService {

    private final AutorRepository autorRepository;

    
    @Autowired
    public AutorService(AutorRepository autorRepository) {
        this.autorRepository = autorRepository;
    }

    public Autor saveAutor(Autor autor) {
        return autorRepository.save(autor);
    }

    public Autor getAutorById(Long id) {
        return autorRepository.findById(id).orElse(null);
    }

    public List<Autor> getAllAutor() {
        return autorRepository.findAll();
    }

    public void deleteAutor(Long id) {
    	autorRepository.deleteById(id);
    }
    public List<Autor> buscarPorTitulo(String titulo){
    	return autorRepository.buscarPorTitutlo(titulo);
    }
}