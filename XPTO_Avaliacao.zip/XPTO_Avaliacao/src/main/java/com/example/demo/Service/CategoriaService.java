package com.example.demo.Service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Categoria;
import com.example.demo.Entities.Livro;
import com.example.demo.Repository.CategoriaRepository;
import com.example.demo.Repository.LivroRepository;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    
    @Autowired
    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public Categoria saveCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    public Categoria getCategoriaById(Long id) {
        return categoriaRepository.findById(id).orElse(null);
    }

    public List<Categoria> getAllCategoria() {
        return categoriaRepository.findAll();
    }

    public void deleteCategoria(Long id) {
    	categoriaRepository.deleteById(id);
    }
    public List<Categoria> buscarPorTitulo(String titulo){
    	return categoriaRepository.buscarPorTitutlo(titulo);
    }
}
