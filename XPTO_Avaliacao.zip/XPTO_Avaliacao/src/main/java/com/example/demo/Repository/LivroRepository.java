package com.example.demo.Repository;

	import java.util.List;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.data.jpa.repository.Query;
	import org.springframework.data.repository.query.Param;

	import com.example.demo.Entities.Livro;

	public interface LivroRepository extends JpaRepository<Livro, Long>{
		@Query(value = "SELECT * FROM Livro 1 WHERE lower(1.titulo) LIKE %:titulo%", nativeQuery = true)
		List<Livro> buscarPorTitutlo(@Param("titulo") String titulo);

	}

