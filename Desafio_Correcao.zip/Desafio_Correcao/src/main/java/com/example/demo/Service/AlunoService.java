package com.example.demo.Service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.Repository.AlunoRepository;
import com.example.demo.Entities.Aluno;
import com.example.demo.Repository.AlunoRepository;

@Service
public class AlunoService {
    private final AlunoRepository alunoRepository;
    
    @Autowired
    public AlunoService(AlunoRepository alunoRepository) {
        this.alunoRepository = alunoRepository;
    }

    public List<Aluno> getAllAluno() {
        return alunoRepository.findAll();
    }

    public Aluno getAlunoById(Long id) {
        Optional<Aluno> aluno = alunoRepository.findById(id);
        return aluno.orElse(null);
    }
    //Query Method 
    @Query
    public List<Aluno> getAllAlunosPorCidade(String cidade) {
        return alunoRepository.findByCidade(cidade); 
      }
    //Query Method 
    @Query
    public List<Aluno> getAllAlunosPorNomeRenda(String nome, Double renda) {
        return alunoRepository.findAll();
      }
    //Query Method 
    @Query
    public List<Aluno> getAllAlunosPorNome(String nome) {
        return alunoRepository.findAll(); 
      }
  //Query Method 
    @Query
    public List<Aluno> getAllCidadeERenda(String cidade, Double renda) {
        return alunoRepository.findAll(); 
      }
  //@query
    @Query
    public List<Aluno> getAllNome(String nome) {
        return alunoRepository.findAll();
    }
  //@query
    @Query
    public List<Aluno> getAllNomeCompleto(String nomeCompleto) {
        return alunoRepository.findAll();
    }
   //@query
    @Query
    public List<Aluno> getAllAlunos(Long id) {
        return alunoRepository.findAll();
    }

    public Aluno saveAluno(Aluno aluno) {
        return alunoRepository.save(aluno);
    }

    public Aluno atualizar (Long id, Aluno aluno) {
    	Aluno exiteAluno = alunoRepository.findById(id)
    			.orElseThrow(() -> new RuntimeException("Aluno " + "Não encontrado"));
    	exiteAluno.setId(aluno.getId());
    	exiteAluno.setAluno(aluno.getAluno());
    	Aluno updateAluno =alunoRepository.save(exiteAluno);
    	return new Aluno(updateAluno.getId(), updateAluno.getAluno());
    	
    	
    }
    public Aluno updateAluno(Long id, Aluno aluno) {
        Optional<Aluno> exiteAluno = alunoRepository.findById(id);
        if (exiteAluno.isPresent()) {
            saveAluno(aluno).setId(id);
            return alunoRepository.save(saveAluno(null));
        }
        return null;
    }

    public boolean deleteAluno(Long id) {
        Optional<Aluno> exiteAluno = alunoRepository.findById(id);
        if (exiteAluno.isPresent()) {
            alunoRepository.deleteById(id);
            return true;
        }else {
        return false;
    }

 
}
}