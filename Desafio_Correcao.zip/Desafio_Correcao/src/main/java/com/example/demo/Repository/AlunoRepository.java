package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.parser.AbstractQueryCreator;

import com.example.demo.Entities.Aluno;

import jakarta.persistence.Column;
import jakarta.persistence.ManyToOne;
import jakarta.validation.Valid;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {

	@Query
	List<Aluno> findByCidade(String nome);
	Aluno findByRa(String ra);	
}